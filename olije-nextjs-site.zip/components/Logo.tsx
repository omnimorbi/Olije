type LogoProps = {
  color?: string;
  ringColor?: string;
  size?: number;
  showWordmark?: boolean;
};

// Accurate two-tone recreation of the official OLIJE mark: a navy circle,
// a gold paisley/comma swirl inset with a white separator ring, and a navy
// wave-tail trailing left. `color` drives the circle + tail (navy on light
// backgrounds, ivory on dark ones) — the gold accent stays constant either
// way since it reads fine on both.
export default function Logo({
  color = "#102A43",
  ringColor = "#F7F3EA",
  size = 34,
  showWordmark = true,
}: LogoProps) {
  const h = size * 0.615;
  return (
    <span className="flex items-center gap-2.5 min-w-0">
      <svg width={size} height={h} viewBox="0 0 130 80" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" className="shrink-0">
        <path d="M2 50c10 3 20 2 28-5" stroke={color} strokeWidth="3.4" strokeLinecap="round" opacity="0.45" />
        <path d="M6 42c10 2.5 19 1 26-6" stroke={color} strokeWidth="3.4" strokeLinecap="round" opacity="0.65" />
        <path d="M10 34c9 2 17 0.5 24-6" stroke={color} strokeWidth="3.4" strokeLinecap="round" opacity="0.88" />
        <circle cx="78" cy="40" r="34" fill={color} />
        <circle cx="63" cy="33" r="19" fill="#B1763F" stroke={ringColor} strokeWidth="3" />
        <circle cx="70" cy="46" r="11" fill={color} />
      </svg>
      {showWordmark && (
        <span
          className="font-serif font-bold tracking-[0.16em] whitespace-nowrap"
          style={{ color, fontSize: size * 0.62 }}
        >
          OLIJE
        </span>
      )}
    </span>
  );
}
