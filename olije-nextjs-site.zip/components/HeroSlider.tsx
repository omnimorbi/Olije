"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

// Default photography (Unsplash License — free for commercial use, no
// attribution required) used until a real hero photo is uploaded via
// /admin → Home Page → "Hero background photo". Once that's set, this
// slider is skipped in favor of the single CMS image (see page.tsx).
const DEFAULT_SLIDES = [
  { src: "https://images.unsplash.com/photo-1726111262949-e22631a8c376?auto=format&fit=crop&w=1920&q=75", alt: "Oil refinery at night" },
  { src: "https://images.unsplash.com/photo-1759272840712-c7e5ea852367?auto=format&fit=crop&w=1920&q=75", alt: "Aerial view of a shipping port" },
  { src: "https://images.unsplash.com/photo-1744113627248-8c9ba859be91?auto=format&fit=crop&w=1920&q=75", alt: "Industrial infrastructure" },
  { src: "https://images.unsplash.com/photo-1760259203238-01708384f7a2?auto=format&fit=crop&w=1920&q=75", alt: "Modern city skyline at dusk" },
];

export default function HeroSlider() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setActive((i) => (i + 1) % DEFAULT_SLIDES.length), 6000);
    return () => clearInterval(id);
  }, []);

  return (
    <>
      <div className="absolute inset-0">
        {DEFAULT_SLIDES.map((slide, i) => (
          <div key={slide.src} className={`absolute inset-0 transition-opacity duration-[1400ms] ${i === active ? "opacity-100" : "opacity-0"}`}>
            <Image
              src={slide.src}
              alt={slide.alt}
              fill
              priority={i === 0}
              sizes="100vw"
              className="object-cover"
            />
          </div>
        ))}
      </div>
      <div className="absolute right-8 bottom-28 sm:bottom-36 z-20 flex flex-col gap-2.5">
        {DEFAULT_SLIDES.map((slide, i) => (
          <button
            key={slide.src}
            onClick={() => setActive(i)}
            aria-label={`Show slide: ${slide.alt}`}
            className={`w-2 h-2 rounded-full border border-ivory/60 transition-all ${
              i === active ? "bg-goldLight border-goldLight scale-125" : "bg-transparent"
            }`}
          />
        ))}
      </div>
    </>
  );
}
