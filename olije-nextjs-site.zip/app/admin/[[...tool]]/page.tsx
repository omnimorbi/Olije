import { NextStudio } from "next-sanity/studio";
import config from "../../../sanity.config";
import { sanityConfigured } from "../../../sanity/env";

export const dynamic = "force-static";

export { metadata, viewport } from "next-sanity/studio";

export default function AdminPage() {
  if (!sanityConfigured) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#0A1D30",
          color: "#F7F3EA",
          fontFamily: "system-ui, sans-serif",
          padding: 24,
        }}
      >
        <div style={{ maxWidth: 560, textAlign: "center" }}>
          <div style={{ fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase", color: "#D9B27C", marginBottom: 16 }}>
            OLIJE Admin
          </div>
          <h1 style={{ fontSize: 28, marginBottom: 16 }}>Admin isn&apos;t connected yet</h1>
          <p style={{ opacity: 0.75, lineHeight: 1.6, marginBottom: 8 }}>
            This panel is a Sanity Studio embedded right inside the site. It just needs a free
            Sanity project ID to switch on.
          </p>
          <p style={{ opacity: 0.75, lineHeight: 1.6 }}>
            See the README section &ldquo;Turning on the admin&rdquo; — create a project at{" "}
            <strong>sanity.io/manage</strong>, then set <code>NEXT_PUBLIC_SANITY_PROJECT_ID</code> in
            your <code>.env.local</code> and restart the dev server.
          </p>
        </div>
      </div>
    );
  }

  return <NextStudio config={config} />;
}
